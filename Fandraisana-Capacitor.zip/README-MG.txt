FANDRAISANA AN-TSORATRA - fanamboarana APK maimaim-poana (Capacitor + GitHub)
Ny HTML dia ao anaty APK mihitsy: tsy mila Netlify, tsy misy bara URL, mandeha offline.

DINGANA (azo atao amin'ny telefaona na PC, ao amin'ny github.com)
1. Mamoròna kaonty GitHub maimaim-poana, dia "New repository" (anarana: fandraisana). Private na Public.
2. Ao amin'ny repository: Add file > Upload files. Alatsaho ireto 5 fichier ireto (aorian'ny extract an'ny zip):
     index.html, icon-512.png, package.json, capacitor.config.json, debug.keystore
   Tsindrio "Commit changes".
3. Add file > Create new file. Ao amin'ny anarana, soraty marina:
     .github/workflows/build-apk.yml
   Ao anatiny, apetraho ny votoatin'ny fichier "build-apk.yml" (sokafy amin'ny Notes, copy-paste). Commit.
4. Tsindrio ny tabilao "Actions". Hita ny "Manamboatra APK" mandeha (3-6 minitra). Raha tsy mandeha: Actions > Manamboatra APK > Run workflow.
5. Rehefa maitso ny dingana: tsindrio ilay run, midina any ambany ao amin'ny "Artifacts", alaivo ny "Fandraisana-An-tsoratra-APK" (zip). Extract: ao anatiny ny app-debug.apk. Apetraho.

FANAMARIHANA
- Ny debug.keystore dia mitazona ny signature mitovy foana, ka afaka manavao APK ambonin'ny taloha tsy mamafa data.
- Ny angona (localStorage) dia ao amin'ny application ihany; tsy mitovy amin'ny angona tao amin'ny dikan-teny Netlify taloha. Ataovy Export aloha raha misy zava-dehibe.
- Hanova ny application: soloy ny index.html ao amin'ny GitHub (Edit/Upload), commit, dia hamboarina APK vaovao.
- Esory ny APK taloha (Fitsidihana avy amin'ny PWABuilder) aloha: hafa ny Package ID sy ny signature.
